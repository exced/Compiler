package mcs.exception;

public class EExistantArgument extends Exception{
	
	public EExistantArgument(String arg){
		super(arg);
	}
	
}
