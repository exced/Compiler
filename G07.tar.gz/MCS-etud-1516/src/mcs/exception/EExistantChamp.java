package mcs.type;

public class EExistantChamp extends Exception {

	public EExistantChamp(String args){
		super(args);
	}
	
}