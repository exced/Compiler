package mcs.egg;
public interface IMCSMessages {

  public static final int id_MCS_unexpected_token = 4194304;
  public static final int id_B_14 = 4194305;
  public static final int id_B_12 = 4194306;
  public static final int id_not_int = 4194307;
  public static final int id_B_11 = 4194308;
  public static final int id_B_08 = 4194309;
  public static final int id_B_10 = 4194310;
  public static final int id_type_undefined = 4194311;
  public static final int id_not_infotype = 4194312;
  public static final int id_MCS_expected_eof = 4194313;
  public static final int id_MCS_expected_token = 4194314;
  public static final int id_affect_notCompatible = 4194315;
  public static final int id_B_01 = 4194316;
  public static final int id_returnType_notCompatible = 4194317;
  public static final int id_var_declared = 4194318;
  public static final int id_not_pointeur = 4194319;
  public static final int id_NO_MACH = 4194320;
  }
