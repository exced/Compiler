package mcs.egg;
public interface IASMMessages {

  public static final int id_NOT_A_VAR = 1966080;
  public static final int id_ASM_expected_eof = 1966081;
  public static final int id_ASM_unexpected_token = 1966082;
  public static final int id_UNKNOWN = 1966083;
  public static final int id_ASM_expected_token = 1966084;
  }
