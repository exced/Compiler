package mcs.egg;
public interface IMCSMessages {

  public static final int id_MCS_expected_token = 4194304;
  public static final int id_MCS_expected_eof = 4194305;
  public static final int id_NO_MACH = 4194306;
  public static final int id_MCS_unexpected_token = 4194307;
  }
