package mcs.compiler;

public class MCSException extends Exception {
	private static final long serialVersionUID = 1L;

	public MCSException(String a) {
		super(a);
	}

}
