//--------------------------------------------------
// INFO la classe representant une info de TDS
//--------------------------------------------------
package mcs.tds;

/**
 * Element d'une TDS
 * 
 * @author marcel
 * 
 */
public interface INFO {

}
